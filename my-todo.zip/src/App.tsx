import React, { useState, useEffect, useRef } from 'react';

import Section from './components/Pages/Section';
import { TodoList } from './components/Models/TodosModel';
import Input from './components/Input';
import SideBar from './components/Pages/SideBar';
import { Todo } from './components/Models/Todo';

function App(): React.JSX.Element {
  const [todolistTitle, setTodolistTitle] = useState<string>('');
  const [todoList, setTodoLists] = useState<TodoList[]>(
    JSON.parse(localStorage.getItem('todos') || '[]') || []
  );
  const [edittodoData, setEditTodoData] = useState<Todo>();
  const sidebarRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        sidebarRef.current &&
        !sidebarRef.current.contains(event.target as Node)
      ) {
        setEditTodoData(undefined);
      }
    };

    const handleEscapeKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setEditTodoData(undefined);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscapeKey);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscapeKey);
    };
  }, []);

  function handleAddTodoList(e: React.SyntheticEvent) {
    e.preventDefault();
    if (todolistTitle) {
      setTodoLists((prevData) => [...prevData, { id: todolistTitle }]);
      setTodolistTitle('');
    }
  }
  useEffect(() => {
    localStorage.setItem('todos', JSON.stringify(todoList));
  }, [todoList]);

  return (
    <div>
      <div className='bg-blue-500 flex justify-center items-center gap-x-4 text-white p-4  font-semibold'>
        <p> My Todo</p>
        <button
          onClick={() =>
            localStorage.getItem('theme') === 'dark'
              ? localStorage.setItem('theme', 'light')
              : localStorage.setItem('theme', 'dark')
          }
        >
          hi
        </button>
      </div>
      <div className='flex justify-between relative'>
        <div className='flex w-full  items-start mt-4 gap-x-4'>
          <div className='flex gap-x-4 items-start'>
            {todoList.map((todos) => {
              return (
                <Section
                  key={todos.id}
                  todoObj={todos}
                  allLists={todoList}
                  setTodoLists={setTodoLists}
                  setEditTodoData={setEditTodoData}
                />
              );
            })}
          </div>
          <Input
            value={todolistTitle}
            setValue={setTodolistTitle}
            placeholder='Enter List name'
            handleSubmit={handleAddTodoList}
          />
        </div>
        <div
          ref={sidebarRef}
          className={`shadow-one h-[91vh] border-l-blue-500 border-t-0 border-b-0 border-r-0 border-4   ease-linear duration-300 absolute z-[80] right-0 overflow-hidden select-none ${
            edittodoData ? 'w-64 ' : 'w-0'
          }`}
        >
          {edittodoData && (
            <SideBar
              id={edittodoData?.id}
              title={edittodoData?.title}
              description={edittodoData?.description}
              setTodoLists={setTodoLists}
              isEdit={true}
              setEditTodoData={setEditTodoData}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
