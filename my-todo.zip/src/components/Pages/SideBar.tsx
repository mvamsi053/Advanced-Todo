import React, { useState } from 'react';
import SectionInput from '../SectionInput';
import { TodoList } from '../Models/TodosModel';
import { Todo } from '../Models/Todo';
import { IoMdArrowRoundBack } from 'react-icons/io';

interface Props {
  id: number;
  title: string;
  description: string;
  setTodoLists: React.Dispatch<React.SetStateAction<TodoList[]>>;
  isEdit?: boolean;
  setEditTodoData: React.Dispatch<React.SetStateAction<Todo | undefined>>;
}

function SideBar({
  title,
  description,
  id,
  setTodoLists,
  isEdit,
  setEditTodoData,
}: Props): React.JSX.Element {
  const [todoTitle, setTodoTitle] = useState<string>(title);
  const [todoDescrip, setTodoDescrip] = useState<string>(description);
  function handleEditTodo(e: React.SyntheticEvent) {
    e.preventDefault();

    if (todoDescrip && todoTitle) {
      setTodoLists((prevLists) => {
        return prevLists.map((list) => {
          const updatedTodos = list.todos?.map((todo) => {
            if (todo.id === id) {
              return {
                ...todo,
                title: todoTitle,
                description: todoDescrip,
              };
            }
            return todo;
          });

          return {
            ...list,
            todos: updatedTodos,
          };
        });
      });
      setEditTodoData(undefined);
    }
  }
  return (
    <div className='flex flex-col items-center '>
      <div className='border-b w-full text-center p-3 font-semibold flex items-center gap-x-4'>
        <IoMdArrowRoundBack
          className='cursor-pointer hover:rotate-180 transition-all ease-in-out duration-200 scale-110 '
          onClick={() => setEditTodoData(undefined)}
        />
        <p></p> Edit todo
      </div>
      <SectionInput
        todoTitle={todoTitle}
        todoDescrip={todoDescrip}
        setTodoTitle={setTodoTitle}
        setTodoDescrip={setTodoDescrip}
        handleSubmit={handleEditTodo}
        isEdit={isEdit}
      />
    </div>
  );
}

export default SideBar;
