import React from 'react';
import { MdEdit } from 'react-icons/md';
import { Todo } from './Models/Todo';

interface Props {
  title: string;
  description: string;
  isDone: boolean;
  id: number;
  setEditTodoData: React.Dispatch<React.SetStateAction<Todo | undefined>>;
}
function TodoCard({
  title,
  setEditTodoData,
  description,
  isDone,
  id,
}: Props): React.JSX.Element {
  return (
    <div className='flex flex-col border rounded-xl my-4 '>
      <div className='flex justify-between items-center py-4 px-2 border-b'>
        <p className='font-semibold'>{title}</p>
        <div
          className='bg-gray-600 p-2 rounded-full hover:drop-shadow-2xl hover:scale-90 transition-all ease-linear cursor-pointer'
          onClick={() =>
            setEditTodoData((prev) => {
              return {
                id: id,
                title: title,
                description: description,
                isDone: isDone,
              };
            })
          }
        >
          <MdEdit />
        </div>
      </div>
      <div className='px-2 py-4'>
        <p>{description}</p>
      </div>
    </div>
  );
}

export default TodoCard;
